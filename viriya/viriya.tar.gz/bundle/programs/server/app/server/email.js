(function(){process.env.MAIL_URL="smtp://nickbutlin%40viriyaenergy.com:Amnes1aNick0s@smtp.gmail.com:465/"; 

})();
