(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Errors;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nickos:errors'] = {
  Errors: Errors
};

})();

//# sourceMappingURL=nickos_errors.js.map
